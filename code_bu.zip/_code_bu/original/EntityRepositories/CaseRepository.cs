﻿using NLog;
using Star.DataAccess.Interfaces;
using Star.DataAccess.Models;
using Star.DataAccess.Models.SPModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Xml.Linq;
using Star.Common;
using Star.Queries;
using Star.Queries.Results;
using Star.DataAccess.Base;

namespace Star.DataAccess.Repositories
{
    public class CaseRepository : EntityRepository<TCase>, ICaseRepository
    {
        private readonly XmlHelper _xmlHelper;

        public CaseRepository(IStarDbContext dbContext, XmlHelper xmlHelper) : base(dbContext)
        {
            _xmlHelper = xmlHelper;
        }

        //public IEnumerable<IDictionary<string, object>> DataList(int caseId, int metaObjectId, string configurationName)
        //{
        //    var caseIdPrm = this.dbContext.CreatePrm("@CaseID", caseId);
        //    var metaObjectIdPrm = this.dbContext.CreatePrm("@MetaObjectID", metaObjectId);
        //    var configurationNamePrm = this.dbContext.CreatePrm("@ConfigurationName", configurationName);

        //    IEnumerable<IDictionary<string, object>> result = this.dbContext.ExecuteDynamic("[dbo].[SMetaObjectDataGet]", CommandType.StoredProcedure, caseIdPrm, metaObjectIdPrm, configurationNamePrm);

        //    return result;
        //}

        public string AllCases(int[] tagIds, Guid userId, int? caseTypeId, int? startRow, int? endRow)
        {
            var startRowPrm = this.dbContext.CreatePrm("@StartRow", startRow);
            var endRowPrm = this.dbContext.CreatePrm("@EndRow", endRow);
            var tagIdsPrm = this.dbContext.CreatePrm("@TagIDs", tagsToXmlString(tagIds));
            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);
            var caseTypeIdPrm = this.dbContext.CreatePrm("@CaseTypeID", caseTypeId);
            string result = this.dbContext.ExecuteJson(Constants.Sp_SCaseGetAll, CommandType.StoredProcedure, startRowPrm, endRowPrm, tagIdsPrm, userIdPrm, caseTypeIdPrm);
            
            return result;
        }

        public int AllCasesCount(int[] tagIds, Guid userId, int? caseTypeId)
        {
            int totalCount = 0;

            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);
            var totalCountPrm = this.dbContext.CreatePrm("@TotalCount", new int());
            totalCountPrm.Direction = ParameterDirection.Output;
            var caseTypeIdPrm = this.dbContext.CreatePrm("@CaseTypeID", caseTypeId);
            var tagsToXml = tagsToXmlString(tagIds);
            var tagIdsPrm = this.dbContext.CreatePrm("@TagIDs", tagsToXml);

            this.dbContext.Execute($"{Constants.Sp_SCaseGetAllCount} @TotalCount OUTPUT, @TagIDs, @UserID, @CaseTypeID", totalCountPrm, tagIdsPrm, userIdPrm, caseTypeIdPrm);

            if (totalCountPrm.Value != DBNull.Value)
            {
                totalCount = Convert.ToInt32(totalCountPrm.Value);
            }

            return totalCount;
        }

        //public IEnumerable<IDictionary<string, object>> RelateDataList(int caseId, int metaObjectRelateId, Guid parentItemId, string configurationName = null)
        //{

        //    var caseIdParameter = this.dbContext.CreatePrm("@CaseID", caseId);
        //    var metaObjectIdParameter = this.dbContext.CreatePrm("@MetaObjectRelateID", metaObjectRelateId);
        //    var parentItemIdParameter = this.dbContext.CreatePrm("@ParentItemID", parentItemId);
        //    var configurationNameParameter = this.dbContext.CreatePrm("@ConfigurationName", configurationName);

        //    IEnumerable<IDictionary<string, object>> result = this.dbContext.ExecuteDynamic("SMetaObjectRelateDataGet", CommandType.StoredProcedure, caseIdParameter, metaObjectIdParameter, parentItemIdParameter, configurationNameParameter);
        //    return result;
        //}

        public IEnumerable<TCase> GetCases(IEnumerable<int> idSet)
        {
            return this.dbContext.Set<TCase>().Where(c => idSet.Contains(c.CaseID)).ToList();
        }

        public string GetCaseInfo(int caseId, int? pageViewId, string pageViewName)
        {
            var caseIdPrm = this.dbContext.CreatePrm("@CaseID", caseId);
            var pageViewIdPrm = this.dbContext.CreatePrm("@PageViewID", pageViewId);
            var pageViewNamePrm = this.dbContext.CreatePrm("@PageViewName", pageViewName);

            var result = this.dbContext.ExecuteJson(Constants.Sp_SCaseGetInfoByCaseID, CommandType.StoredProcedure,
                caseIdPrm, pageViewIdPrm, pageViewNamePrm);

            return result;
        }

        public IEnumerable<TWorkFlowHistory> GetCaseWorkFlowHistory(int caseId)
        {
            List<TWorkFlowHistory> result = null;

            var tCaseWorkFlowHistory = dbContext.Set<TCaseWorkFlowHistory>().AsNoTracking();
            var tWorkFlowPosition = dbContext.Set<TWorkFlowPosition>().AsNoTracking();
            var tWorkFlowHorizontal = dbContext.Set<TWorkFlowHorizontal>().AsNoTracking();
            var tWorkFlowVertical = dbContext.Set<TWorkFlowVertical>().AsNoTracking();
            var tWorkFlowRoute = dbContext.Set<TWorkFlowRoute>().AsNoTracking();


            result = (from cwfh in tCaseWorkFlowHistory
                      join wfpFrom in tWorkFlowPosition on cwfh.FromWorkFlowPositionID equals wfpFrom.WorkFlowPositionID into j1
                      from t1 in j1.DefaultIfEmpty()
                      join wfhFrom in tWorkFlowHorizontal on t1.WorkFlowHorizontalID equals wfhFrom.WorkFlowHorizontalID into j2
                      from t2 in j2.DefaultIfEmpty()
                      join wfpTo in tWorkFlowPosition on cwfh.ToWorkFlowPositionID equals wfpTo.WorkFlowPositionID
                      join wfvTo in tWorkFlowVertical on wfpTo.WorkFlowVerticalID equals wfvTo.WorkFlowVerticalID
                      join wfhTo in tWorkFlowHorizontal on wfpTo.WorkFlowHorizontalID equals wfhTo.WorkFlowHorizontalID
                      join wfr in tWorkFlowRoute on cwfh.WorkFlowRouteID equals wfr.WorkFlowRouteID into j4
                      from t4 in j4.DefaultIfEmpty()
                      where cwfh.CaseID == caseId
                      orderby cwfh.CreatedOn descending
                      select new TWorkFlowHistory
                      {
                          CaseWorkFlowHistoryId = cwfh.CaseWorkFlowHistoryID,
                          Date = cwfh.CreatedOn,
                          FromUserId = cwfh.FromUserID,
                          FromWorkFlowPositionId = cwfh.FromWorkFlowPositionID,
                          FromWorkFlowHorizontalName = t2.WorkFlowHorizontalName,
                          WorkFlowRouteId = cwfh.WorkFlowRouteID,
                          WorkFlowRouteName = t4.WorkFlowRouteName,
                          Action = (
                           cwfh.Action == "P" ? "Promote" :
                           cwfh.Action == "D" ? "Demote" :
                           cwfh.Action == "A" ? "Assign" : null),
                          ToUserId = cwfh.ToUserID,
                          ToWorkFlowPositionID = cwfh.ToWorkFlowPositionID,
                          ToWorkFlowHorizontalName = wfhTo.WorkFlowHorizontalName,
                          ToWorkFlowVerticalName = wfvTo.WorkFlowVerticalName,
                          Comments = cwfh.Comments ?? null,
                          ModifiedByUserId = cwfh.CreatedByUserID 
                      }).ToList();

            return result;

        }

        public IEnumerable<TComments> GetCaseWorkFlowHistoryComments(int caseId)
        {
            var tCaseWorkFlowHistory = dbContext.Set<TCaseWorkFlowHistory>().AsNoTracking().Where(e => e.CaseID == caseId && !String.IsNullOrEmpty(e.Comments));

            var result = (from cwfh in tCaseWorkFlowHistory
                          select new TComments
                          {
                              CaseWorkFlowHistoryId = cwfh.CaseWorkFlowHistoryID,
                              Comments = cwfh.Comments
                          }).ToList();

            return result;
        }

        public string AllUserCases(Guid userId, int[] tagIds, int? caseTypeId, int? startRow, int? endRow)
        {
            var userIdPrm = this.dbContext.CreatePrm("@AssignedToUserID", userId);
            var startRowPrm = this.dbContext.CreatePrm("@StartRow", startRow);
            var endRowPrm = this.dbContext.CreatePrm("@EndRow", endRow);
            var tagIdsPrm = this.dbContext.CreatePrm("@TagIDs", tagsToXmlString(tagIds));
            var caseTypeIdPrm = this.dbContext.CreatePrm("@CaseTypeId", caseTypeId);
            string result = this.dbContext.ExecuteJson(Constants.Sp_SCaseGetByAssignedToUserID, CommandType.StoredProcedure, userIdPrm, startRowPrm, endRowPrm, tagIdsPrm, caseTypeIdPrm);
            return result;
        }

        public string GetAssignedCases(Guid[] userIds, int caseTypeId, int workFlowHorizontalId, int? startRow, int? endRow)
        {
            string result = "";

            if (userIds != default(Guid[]))
            {
                string xml = createUserIdsXml("users", "user", "id", userIds);

                var userIdPrm = this.dbContext.CreatePrm("@UserIDs", xml);
                var startRowPrm = this.dbContext.CreatePrm("@StartRow", startRow);
                var endRowPrm = this.dbContext.CreatePrm("@EndRow", endRow);
                var caseTypeIdPrm = this.dbContext.CreatePrm("@CaseTypeId", caseTypeId);
                var workFlowHorizontalIdPrm = this.dbContext.CreatePrm("@WorkFlowHorizontalID", workFlowHorizontalId);
                result = this.dbContext.ExecuteJson(Constants.Sp_SCaseGetByAssignedToUserList, CommandType.StoredProcedure, userIdPrm, caseTypeIdPrm, workFlowHorizontalIdPrm, startRowPrm, endRowPrm);
            }

            return result;
        }

        private string createUserIdsXml(string rootNodeName, string nodeName, string propertyName, Guid[] userIds)
        {
            XElement xml = new XElement(rootNodeName);

            for (int count = 0; count < userIds.Length; count++)
            {
                XElement elm = new XElement(nodeName,
                  new XAttribute(propertyName, userIds[count]));

                xml.Add(elm);
            }

            return xml.ToString(SaveOptions.DisableFormatting);
        }

        public IEnumerable<AllCaseStatusesResult> GetAllCaseStatuses(int applicationModuleId)
        {
            var workFlowHorizontal = this.dbContext.Set<TWorkFlowHorizontal>().AsNoTracking();
            var workFlowPosition = this.dbContext.Set<TWorkFlowPosition>().AsNoTracking();
            var workFlow = this.dbContext.Set<TWorkFlow>().AsNoTracking();

            var result =
                (from wfh in workFlowHorizontal
                 join wfp in workFlowPosition on wfh.WorkFlowHorizontalID equals wfp.WorkFlowHorizontalID
                 join wff in workFlow on wfp.WorkFlowPositionID equals wff.FromWorkFlowPositionID into j1
                 from t1 in j1.DefaultIfEmpty()
                 join wft in workFlow on wfp.WorkFlowPositionID equals wft.ToWorkFlowPositionID into j2
                 from t2 in j2.DefaultIfEmpty()
                 where wfh.ApplicationModuleID == applicationModuleId && (t1 != null || t2 != null)
                 select new
                 {
                     WorkFlowHorizontalId = wfh.WorkFlowHorizontalID,
                     WorkFlowHorizontalName = wfh.WorkFlowHorizontalName,
                     IsFinalPosition = wfh.IsFinalPosition,
                     IsCreationPosition = wfh.IsCreationPosition,
                     IsAssignmentPosition = wfh.IsAssignmentPosition
                 }).Distinct().Select(e => new AllCaseStatusesResult
                 {
                     WorkFlowHorizontalId = e.WorkFlowHorizontalId,
                     WorkFlowHorizontalName = e.WorkFlowHorizontalName,
                     IsFinalPosition = e.IsFinalPosition,
                     IsCreationPosition = e.IsCreationPosition,
                     IsAssignmentPosition = e.IsAssignmentPosition
                 }).ToList();

            return result;
        }

        public int GetAllUserCasesCount(Guid userId, int[] tagIds, int? caseTypeId)
        {
            int totalCount = 0;

            var userIdPrm = this.dbContext.CreatePrm("@AssignedToUserID", userId);
            var totalCountPrm = this.dbContext.CreatePrm("@TotalCount", new int());
            var caseTypeIdPrm = this.dbContext.CreatePrm("@CaseTypeId", caseTypeId);
            totalCountPrm.Direction = ParameterDirection.Output;
            var tagIdsPrm = this.dbContext.CreatePrm("@TagIDs", tagsToXmlString(tagIds));

            this.dbContext.Execute($"{Constants.Sp_SCaseGetByAssignedToUserIDCount} @AssignedToUserID, @TotalCount output, @TagIDs, @CaseTypeId", userIdPrm, totalCountPrm, tagIdsPrm, caseTypeIdPrm);

            if (totalCountPrm.Value != DBNull.Value)
            {
                totalCount = Convert.ToInt32(totalCountPrm.Value);
            }

            return totalCount;
        }

        public IEnumerable<CaseCategoryResult> GetCaseCategories()
        {
            var caseCategories = this.dbContext.Set<TCaseCategory>().AsNoTracking().ToList();

            var result =
                (from category in caseCategories
                 select new CaseCategoryResult
                 {
                     CaseCategoryID = category.CaseCategoryID,
                     CaseCategoryName = category.CaseCategoryName
                 }).ToList();

            return result;
        }

        public IEnumerable<CasesForMovingItemsResult> GetCasesForMovingItems(int exculdedCaseId, string caseNameFilter)
        {
            //OR:
            // && (tCase.CaseName != null && tCase.CaseName.Contains(caseNameFilter)
            //                     || tCase.CaseID.ToString().Contains(caseNameFilter))
            var result = (from tCase in dbContext.Set<TCase>()
                          join wfp in dbContext.Set<TWorkFlowPosition>() on tCase.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID into wfhList
                          from wfhLeft in wfhList.DefaultIfEmpty()
                          join caseType in this.dbContext.Set<CaseType>() on tCase.CaseTypeID equals caseType.CaseTypeID
                          where tCase.CaseID != exculdedCaseId
                                && wfhLeft.WorkFlowHorizontalName != Constants.WorkFlowHorizontalCompleteStatusName
                                && wfhLeft.MoveItemRights
                                && (tCase.CaseName != null && tCase.CaseName.Contains(caseNameFilter) || tCase.CaseID.ToString().Contains(caseNameFilter))
                                && caseType.CaseTypeName == Constants.CaseTypeName_RegularCase
                                && !tCase.IsLocked
                          select new CasesForMovingItemsResult
                          {
                              CaseId = tCase.CaseID,
                              CaseName = tCase.CaseName,
                              CaseStatus = wfhLeft.WorkFlowHorizontalName
                          }).AsNoTracking().ToList();

            return result;
        }

        public void MoveItem(Guid itemId, int caseIdTo, int caseIdFrom, Guid userId)
        {
            var itemIdParameter = this.dbContext.CreatePrm("@ItemID", itemId);
            var caseIdToParameter = this.dbContext.CreatePrm("@CaseIDTo", caseIdTo);
            var caseIdFromParameter = this.dbContext.CreatePrm("@CaseIDFrom", caseIdFrom);
            var userIdParameter = this.dbContext.CreatePrm("@UserID", userId);

            var result = string.Empty;
            this.dbContext.Execute($"{Constants.Sp_SCaseItemMove} @ItemID, @CaseIDTo, @CaseIDFrom, @UserID",
                itemIdParameter, caseIdToParameter, caseIdFromParameter, userIdParameter);
        }

        public IEnumerable<ManualCaseSelectCasesResult> GetSelectCasesManualCreation(int caseViewTabGroupId)
        {
            var rootItemCountQuery = (from item in dbContext.Set<Item>()
                                      join caseItem in dbContext.Set<TCaseItem>() on item.ItemID equals caseItem.ItemID
                                      join metaObject in dbContext.Set<TMetaObject>() on item.MetaObjectID equals metaObject.Id
                                      where metaObject.IsRoot
                                      group item by new { caseItem.CaseID, metaObject.MetaObjectName }
                into itemsGroup
                                      select new
                                      {
                                          itemsGroup.Key.CaseID,
                                          RootItemCount = itemsGroup.Select(i => i.ItemID).Distinct().Count()
                                      });

            var result = (from tCase in dbContext.Set<TCase>()
                          join wfp in dbContext.Set<TWorkFlowPosition>() on tCase.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID into wfhList
                          from wfhLeft in wfhList.DefaultIfEmpty()
                          join riCount in rootItemCountQuery on tCase.CaseID equals riCount.CaseID into riCountList
                          from riCountLeft in riCountList.DefaultIfEmpty()
                          join mUser in dbContext.Set<aspnet_User>() on tCase.ModifiedByUserID equals mUser.UserID into mUserList
                          from mUserLeft in mUserList.DefaultIfEmpty()
                          join caseCategory in dbContext.Set<TCaseCategory>() on tCase.CaseCategoryID equals caseCategory.CaseCategoryID into caseCategoryList
                          from caseCategoryLeft in caseCategoryList.DefaultIfEmpty()
                          join caseType in this.dbContext.Set<CaseType>() on tCase.CaseTypeID equals caseType.CaseTypeID
                          where wfhLeft.IsCreationPosition && tCase.CaseViewTabGroupID == caseViewTabGroupId
                                && caseType.CaseTypeName == Constants.CaseTypeName_RegularCase
                                && !tCase.IsLocked
                          select new ManualCaseSelectCasesResult
                          {
                              CaseId = tCase.CaseID,
                              CaseName = tCase.CaseName,
                              CategoryName = caseCategoryLeft.CaseCategoryName,
                              ItemCount = riCountLeft.RootItemCount,
                              DateModified = tCase.ModifiedOn,
                              ModifiedBy = mUserLeft.UserName
                          }).AsNoTracking().ToList();

            return result;
        }

        private string tagsToXmlString(int[] tagIds)
        {
            string tagsXmlString = null;
            if (tagIds != null)
            {
                XDocument tagsXml = new XDocument();
                tagsXml.Add(new XElement("Tags", tagIds.Select(x => new XElement("TagID", x))));
                tagsXmlString = tagsXml.ToString();
            }

            return tagsXmlString;
        }

        private string IdsToXmlString<T>(T[] Ids, string parentElement, string childElement)
        {
            string resultXmlString = null;
            if (Ids != null)
            {
                XDocument resultXml = new XDocument();
                resultXml.Add(new XElement(parentElement, Ids.Select(x => new XElement(childElement, x))));
                resultXmlString = resultXml.ToString();
            }

            return resultXmlString;
        }

        public int GetWorkFlowPositionId(string workFlowVerticalName, string workFlowHorizontalName)
        {
            var workFlowPosition = this.dbContext.Set<TWorkFlowPosition>().AsNoTracking();
            var workFlowVertical = this.dbContext.Set<TWorkFlowVertical>().AsNoTracking();
            var workFlowHorizontal = this.dbContext.Set<TWorkFlowHorizontal>().AsNoTracking();

            var result =
                (from wfp in workFlowPosition
                 join wfv in workFlowVertical on wfp.WorkFlowVerticalID equals wfv.WorkFlowVerticalID
                 join wfh in workFlowHorizontal on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                 where (wfv.WorkFlowVerticalName == workFlowVerticalName) && (wfh.WorkFlowHorizontalName == workFlowHorizontalName)
                 select wfp.WorkFlowPositionID).FirstOrDefault();

            return result;
        }

        public void UnAssignItemsFromRefineCase(Guid[] itemsId, int caseId)
        {
            var caseIdPrm = this.dbContext.CreatePrm("@CaseID", caseId);
            var itemIdsPrm = this.dbContext.CreatePrm("@ItemIDs", IdsToXmlString(itemsId, "ItemIDs", "ItemID"));

            this.dbContext.Execute($"{Constants.Sp_SCaseRefineUnassignItemIDs} @ItemIDs, @CaseID", itemIdsPrm, caseIdPrm);
        }

        public IEnumerable<VerifyMetaObjects> GetVerifyMetaObjects(Guid userId)
        {
            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);

            var result = this.dbContext.Execute<VerifyMetaObjects>($"{Constants.Sp_SCaseCreationGetVerifyData} @UserID", userIdPrm);

            return result;
        }

        public void ProcessVerifyMetaObjects(string[] groupNames, Guid userId)
        {
            var groupNamesPrm = this.dbContext.CreatePrm("@GroupNames", IdsToXmlString(groupNames, "GroupNames", "GroupName"));
            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);

            this.dbContext.Execute($"{Constants.Sp_SCaseCreationProcessVerifyData} @GroupNames, @UserID", groupNamesPrm, userIdPrm);
        }

        public IEnumerable<TCase> GetTagCases(int tagId)
        {
            var result = new List<TCase>();

            var entityFromDb = dbContext.Set<TCaseTag>().Where(c => c.CaseTagID == tagId).Include(c => c.TCases).FirstOrDefault();

            if (entityFromDb != default(TCaseTag))
            {
                result = entityFromDb.TCases.ToList();
            }

            return result;
        }

        public string GetCasesByWfHorizontal(int workFlowHorizontalId, Guid userId, int? startRow, int? endRow)
        {
            //TODO: PERFORMANCE TEST
                        
            var workFlowHorizontalIdPrm = this.dbContext.CreatePrm("@WorkFlowHorizontalID", workFlowHorizontalId);
            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);
            var startRowPrm = this.dbContext.CreatePrm("@StartRow", startRow);
            var endRowPrm = this.dbContext.CreatePrm("@EndRow", endRow);

            var result = this.dbContext.ExecuteJson(Constants.Sp_SCaseGetByWorkFlowHorizontalID, CommandType.StoredProcedure, workFlowHorizontalIdPrm, userIdPrm, startRowPrm, endRowPrm);

            return result;
        }

        public int GetCasesByWfHorizontalCount(int workFlowHorizontalId, Guid userId)
        {
            //TODO: PERFORMANCE TEST
           
            int totalCount = 0;

            var workFlowHorizontalIdPrm = this.dbContext.CreatePrm("@WorkFlowHorizontalID", workFlowHorizontalId);
            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);
            var totalCountPrm = this.dbContext.CreatePrm("@TotalCount", new int());
            totalCountPrm.Direction = ParameterDirection.Output;

            this.dbContext.Execute($"{Constants.Sp_SCaseGetByWorkFlowHorizontalIDCount} @WorkFlowHorizontalID, @UserID, @TotalCount output", workFlowHorizontalIdPrm, userIdPrm, totalCountPrm);

            if (totalCountPrm.Value != DBNull.Value)
            {
                totalCount = Convert.ToInt32(totalCountPrm.Value);
            }
            
            return totalCount;
        }

        public void AssignCaseItemToCase(TCase tCase, TCaseItem caseItemToBeAssigned)
        {
            tCase.TCaseItems.Add(caseItemToBeAssigned);
        }

        public IEnumerable<CaseParty> GetCasesUsingParty(string partyName, int? excludedCaseId)
        {
            var partyNamePrm = this.dbContext.CreatePrm("@PartyName", partyName);
            var excludedCaseIdPrm = this.dbContext.CreatePrm("@CaseID", excludedCaseId);

            var result = this.dbContext.Execute<CaseParty>($"{Constants.Sp_SCaseGetByPartyName} @PartyName, @CaseID", partyNamePrm, excludedCaseIdPrm);

            return result;
        }
        
        public IEnumerable<CaseDispositionResult> GetCasesUsingDisposition(string partyName, int? excludedCaseId)
        {
            var partyNamePrm = this.dbContext.CreatePrm("@PartyName", partyName);
            var excludedCaseIdPrm = this.dbContext.CreatePrm("@ExcludedCaseID", excludedCaseId);

            var result = this.dbContext.Execute<CaseDispositionResult>($"{Constants.Sp_SCaseDispositionGetUsingByPartyName} @PartyName, @ExcludedCaseID", partyNamePrm, excludedCaseIdPrm);

            return result;
        }

        public CountResult GetAssignedCasesCount(Guid[] userIds, int caseTypeId, int workFlowHorizontalId)
        {
            CountResult result = null;

            string xml = createUserIdsXml("users", "user", "id", userIds);
            var caseTypeIdPrm = this.dbContext.CreatePrm("@CaseTypeID", caseTypeId);
            var workFlowHorizontalIdPrm = this.dbContext.CreatePrm("@WorkFlowHorizontalID", workFlowHorizontalId);
            var totalCountPrm = this.dbContext.CreatePrm("@TotalCount", new int());
            totalCountPrm.Direction = ParameterDirection.Output;
            var userIdPrm = this.dbContext.CreatePrm("@UserIDs", xml);

            this.dbContext.Execute($"{Constants.Sp_SCaseGetByAssignedToUserListCount} @UserIDs, @CaseTypeID, @WorkFlowHorizontalID, @TotalCount output", userIdPrm, caseTypeIdPrm, workFlowHorizontalIdPrm, totalCountPrm);

            if (totalCountPrm.Value != DBNull.Value)
            {
                result = new CountResult
                {
                    Count = Convert.ToInt32(totalCountPrm.Value)
                };
            }

            return result;
        }

        public void RecalculateItemCountForCaseAndSave(int caseId)
        {
            var caseIdPrm = this.dbContext.CreatePrm("@CaseID", caseId);

            this.dbContext.Execute($"{Constants.Sp_SCaseRefreshItemCount} @CaseID", caseIdPrm);
        }

        public CaseDisposition GetCaseDisposition(int caseId, int? caseDispositionId)
        {
            var caseDispisitionQuery = (from tCaseDisposition in dbContext.Set<CaseDisposition>()
                                        where tCaseDisposition.CaseID == caseId
                                              && caseDispositionId == null || tCaseDisposition.CaseDispositionID == caseDispositionId
                                        select tCaseDisposition).AsNoTracking();

            var result = caseDispisitionQuery.FirstOrDefault();

            return result;
        }

        public TCaseWorkFlowHistory GetLastCaseWorkFlowHistory(int caseId)
        {
            var result = this.dbContext.Set<TCaseWorkFlowHistory>()
                .Where(tCaseWorkFlowHistory => tCaseWorkFlowHistory.CaseID == caseId)
                .OrderByDescending(tCaseWorkFlowHistory => tCaseWorkFlowHistory.CaseWorkFlowHistoryID)
                .FirstOrDefault();

            return result;
        }

        //public void Assign(Guid userId, int caseId, int workFlowRouteId)
        //{
        //    var caseData = this.dbContext.Set<TCase>().Where(e => e.CaseID == caseId).AsNoTracking().FirstOrDefault();

        //    if(caseData.WorkFlowPositionID == null)
        //    {
        //        throw new ArgumentNullException("Current Position is required.");
        //    }

        //    if (caseData.WorkFlowRouteID == null)
        //    {
        //        throw new ArgumentNullException("Route is required.");
        //    }

        //    var caseIdPrm = this.dbContext.CreatePrm("@CaseID", caseId);
        //    var userIdPrm = this.dbContext.CreatePrm("@NextUserID", userId);
        //    var workFlowRouteIdPrm = this.dbContext.CreatePrm("@WorkFlowRouteID", workFlowRouteId);
        //    var commentsPrm = this.dbContext.CreatePrm("@Comments", "Comment"); //TODO

        //    this.dbContext.Execute("[dbo].[SCasePromote] @CaseID, @NextUserID, @WorkFlowRouteID, @Comments", caseIdPrm, userIdPrm, workFlowRouteIdPrm, commentsPrm);

        //}

        public IEnumerable<TCase> GetCasesForExportSars(DateTime? fromD, DateTime? toD)
        {
            var casesSet = this.dbContext.Set<TCase>();
            var caseExportBatch = this.dbContext.Set<TCaseSARExportBatch>();
            var workFlowPositionSet = this.dbContext.Set<TWorkFlowPosition>();
            var workFlowHorizontalSet = this.dbContext.Set<TWorkFlowHorizontal>();
            var workFlowVerticalSet = this.dbContext.Set<TWorkFlowVertical>();

            var result = (from c in casesSet
                          join wfPos in workFlowPositionSet on c.WorkFlowPositionID equals wfPos.WorkFlowPositionID
                          join wfHor in workFlowHorizontalSet on wfPos.WorkFlowHorizontalID equals wfHor.WorkFlowHorizontalID
                          join wfVer in workFlowVerticalSet on wfPos.WorkFlowVerticalID equals wfVer.WorkFlowVerticalID
                          where wfHor.IsFinalPosition && wfHor.IsSARFinalPosition && c.CompletedOn.HasValue
                              && ((fromD == null && toD == null) || (DbFunctions.TruncateTime(c.CompletedOn) >= DbFunctions.TruncateTime(fromD) 
                              && DbFunctions.TruncateTime(c.CompletedOn) <= DbFunctions.TruncateTime(toD)))
                              && c.SARFile != null
                              && c.SARFileName != null
                              && !(caseExportBatch.Any(es => es.CaseID == c.CaseID))
                          select c);
            return result.ToList();
        }

        public CaseSarSummary GetCaseSarSummary(int caseId)
        {
            var caseIdPrm = this.dbContext.CreatePrm("@CaseID", caseId);

            var result = this.dbContext.Execute<CaseSarSummary>($"{Constants.Sp_SCaseGetSarSummary} @CaseID", caseIdPrm).FirstOrDefault();

            return result;
        }

        public CaseSarAttributesResult GetCaseSarAttributes(int caseId)
        {
            var caseSarSummary = GetCaseSarSummary(caseId);

            var result = (from c in this.dbContext.Set<TCase>()
                         join s in this.dbContext.Set<TSARType>() on c.SARTypeID equals s.SARTypeID into j
                         from t in j.DefaultIfEmpty()
                         where c.CaseID == caseId
                         select new CaseSarAttributesResult
                         {
                             SarFileName = c.SARFileName,
                             ModifiedOn = c.SARModifiedOn,
                             AmendedSarTypeId = t != default(TSARType) ? (int?)t.SARTypeID : null,
                             AmendedSarTypeName = t != default(TSARType) ? t.Value : String.Empty,
                             DateRangeStart = caseSarSummary.DateRangeStart,
                             DateRangeEnd = caseSarSummary.DateRangeEnd,
                             TotalAmount = caseSarSummary.TotalAmount,
                             IsSARFileOutdated = c.IsSARFileOutdated
                         }).FirstOrDefault();
                                          
            return result;
        }

        public bool IsWorkFlowHorizontalUsedInAnyCase(int workFlowHorizontalId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          where wfp.WorkFlowHorizontalID == workFlowHorizontalId
                          select c.CaseID).Any();

            return result;
        }

        public bool IsCaseCreationPosition(int caseId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where c.CaseID == caseId && wfh.IsCreationPosition
                          select c.CaseID).Any();

            return result;
        }

        public bool IsCaseFinalPosition(int caseId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where c.CaseID == caseId && wfh.IsFinalPosition
                          select c.CaseID).Any();

            return result;
        }

        public bool IsCaseAssignmentPosition(int caseId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where c.CaseID == caseId && wfh.IsAssignmentPosition
                          select c.CaseID).Any();

            return result;
        }                

        public bool IsCaseLockablePosition(int caseId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where c.CaseID == caseId && wfh.IsCaseLockable
                          select c.CaseID).Any();

            return result;
        }

        public int GetCountOfAssignedCases(Guid userId)
        {
            int count = 0;
            count = dbContext.Set<TCase>().Count(x => x.AssignedToUserID == userId);

            return count;
        }

        public bool IsAnyLinkedCaseAvailableForAdding(Guid? userId, string caseTabGroupName)
        {
            var result = LinkedCasesAvailableForAddingQuery(userId, caseTabGroupName, null).Any();

            return result;
        }

        public IEnumerable<TCase> GetLinkedCasesAvailableForAdding(Guid? userId, string caseTabGroupName, string caseSearchFilter)
        {
            var result = LinkedCasesAvailableForAddingQuery(userId, caseTabGroupName, caseSearchFilter).ToList();

            return result;
        }

        public bool IsRegularCase(int caseId)
        {
            var result = (from tCase in dbContext.Set<TCase>()
                          join caseType in this.dbContext.Set<CaseType>() on tCase.CaseTypeID equals caseType.CaseTypeID
                          where tCase.CaseID == caseId && caseType.CaseTypeName == Constants.CaseTypeName_RegularCase
                          select tCase.CaseID).Any();

            return result;
        }

        private IQueryable<TCase> LinkedCasesAvailableForAddingQuery(Guid? userId, string caseTabGroupName, string caseSearchFilter)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          join caseType in this.dbContext.Set<CaseType>() on c.CaseTypeID equals caseType.CaseTypeID
                          join cvtg in this.dbContext.Set<CaseViewTabsGroup>() on c.CaseViewTabGroupID equals cvtg.CaseViewTabGroupID
                          where (userId == null || c.AssignedToUserID == userId) 
                                && cvtg.CaseTabGroupName == caseTabGroupName 
                                && !wfh.IsFinalPosition
                                && caseType.CaseTypeName == Constants.CaseTypeName_LinkedCase
                                && (caseSearchFilter == null || caseSearchFilter != null && (c.CaseName != null && c.CaseName.Contains(caseSearchFilter)
                                                                                          || c.CaseID.ToString().Contains(caseSearchFilter)))
                          select c);

            return result;
        }

        public IEnumerable<int> GetCaseTypes(int[] caseIds)
        {
            var result = this.dbContext.Set<TCase>().Where(e => caseIds.Contains(e.CaseID)).Select(e => e.CaseTypeID).Distinct().ToList();

            return result;
        }

        public string LinkedCases(int caseId)
        {            
            var caseIdPrm = this.dbContext.CreatePrm("@CaseID", caseId);
            string result = this.dbContext.ExecuteJson(Constants.Sp_SCaseGetLinkedCasesByCaseID, CommandType.StoredProcedure, caseIdPrm);
                        
            return result;
        }

        public bool AreRegularItemsAddedAsLinkedSarItems(int caseId, int linkedCaseId)
        {
            var result = (from caseItemSAR in this.dbContext.Set<TCaseItemSAR>()
                          join caseItem in this.dbContext.Set<TCaseItem>() on caseItemSAR.ItemID equals caseItem.ItemID
                          where caseItemSAR.CaseID == linkedCaseId && caseItem.CaseID == caseId
                          select caseItemSAR.CaseItemSarID).Any();

            return result;
        }

        public IEnumerable<TCase> LinkedCaseRootCases(int linkedCaseId)
        {
            var result = this.dbContext.Set<TCase>().Where(e => e.LinkedCaseID == linkedCaseId).ToList();
            return result;
        }

        public string GetCasesForLinking(int linkedCaseId, Guid userId, int? startRow, int? endRow)
        {
            var linkedCaseIdPrm = this.dbContext.CreatePrm("@LinkedCaseID", linkedCaseId);
            var startRowPrm = this.dbContext.CreatePrm("@StartRow", startRow);
            var endRowPrm = this.dbContext.CreatePrm("@EndRow", endRow);
            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);
            string result = this.dbContext.ExecuteJson(Constants.Sp_SCaseGetCasesForLinking, CommandType.StoredProcedure,
                linkedCaseIdPrm, userIdPrm, startRowPrm, endRowPrm);

            return result;
        }

        public int GetCasesForLinkingCount(int linkedCaseId, Guid userId)
        {
            int totalCount = 0;

            var linkedCaseIdPrm = this.dbContext.CreatePrm("@LinkedCaseID", linkedCaseId);
            var userIdPrm = this.dbContext.CreatePrm("@UserID", userId);
            var totalCountPrm = this.dbContext.CreatePrm("@TotalCount", default(int), ParameterDirection.Output);

            this.dbContext.Execute($"{Constants.Sp_SCaseGetCasesForLinkingCount} @LinkedCaseID, @UserID, @TotalCount OUTPUT", 
                linkedCaseIdPrm, userIdPrm, totalCountPrm);

            if (totalCountPrm.Value != DBNull.Value)
            {
                totalCount = Convert.ToInt32(totalCountPrm.Value);
            }

            return totalCount;
        }

        public bool IsCaseLinkingAllowedPosition(int caseId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where c.CaseID == caseId && wfh.IsCaseLinkingAllowed
                          select c.CaseID).Any();

            return result;
        }

        public bool IsLinkedCase(int caseId)
        {
            var result = (from tCase in dbContext.Set<TCase>()
                          join caseType in this.dbContext.Set<CaseType>() on tCase.CaseTypeID equals caseType.CaseTypeID
                          where tCase.CaseID == caseId && caseType.CaseTypeName == Constants.CaseTypeName_LinkedCase
                          select tCase.CaseID).Any();

            return result;
        }

        public void PromoteAll(int[] caseIds, Guid[] userIds, Guid currentUserId, int workflowRouteId, string comments, string action)
        {            
            var caseIdsPrm = dbContext.CreatePrm("@CaseIDs", _xmlHelper.IdsToXmlString(caseIds, "IDs", "ID"));
            var userIdsPrm = dbContext.CreatePrm("@NextUserIDs", _xmlHelper.IdsToXmlString(userIds, "IDs", "ID"));
            var currentUserIdPrm = dbContext.CreatePrm("@ModifiedByUserID", currentUserId);
            var workflowRouteIdPrm = dbContext.CreatePrm("@WorkFlowRouteID", workflowRouteId);
            var commentsPrm = dbContext.CreatePrm("@Comments", comments);        
            var actionPrm = dbContext.CreatePrm("@Action", action);

            this.dbContext.Execute(
                $"{Constants.Sp_SCaseAssignPromote} @CaseIDs, @NextUserIDs, @ModifiedByUserID, @WorkFlowRouteID, @Comments, @Action",
                caseIdsPrm, userIdsPrm, currentUserIdPrm, workflowRouteIdPrm, commentsPrm, actionPrm);
        }

        public IEnumerable<CaseWorkflowPositionDetails> GetCaseWorkflowPositionDetails(int[] caseIds)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where caseIds.Contains(c.CaseID)
                          select new CaseWorkflowPositionDetails
                          {
                              CaseId = c.CaseID,
                              AssignedToUserId = c.AssignedToUserID,
                              IsCaseAssignmentPosition = wfh.IsAssignmentPosition,
                              IsCaseCreationPosition = wfh.IsCreationPosition,
                              IsCaseFinalPosition = wfh.IsFinalPosition
                          }).ToList();

            return result;
        }

        public bool IsClearedFollowUpFlagPosition(int caseId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where c.CaseID == caseId && wfh.ClearFollowUpFlag
                          select c.CaseID).Any();

            return result;
        }

        public bool IsCaseMoveItemsAllowed(int caseId)
        {
            var result = (from c in this.dbContext.Set<TCase>()
                          join wfp in this.dbContext.Set<TWorkFlowPosition>() on c.WorkFlowPositionID equals wfp.WorkFlowPositionID
                          join wfh in this.dbContext.Set<TWorkFlowHorizontal>() on wfp.WorkFlowHorizontalID equals wfh.WorkFlowHorizontalID
                          where c.CaseID == caseId && wfh.MoveItemRights
                          select c.CaseID).Any();

            return result;
        }
    }
}