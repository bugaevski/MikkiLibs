﻿using System;

namespace Star.Common
{
    public class Constants
    {
        public static readonly Guid TemporaryHardcodedUserId = new Guid("BEC0DB84-7D86-46E6-BD86-86D3D7B3E88E");

        public static readonly string BaseUrl = "BaseUrl";
        public static readonly string PageViewCategory_MetaObject = "MetaObject";
        public static readonly string PageViewCategory_Predefined = "Predefined";
        public static readonly string PageViewCategory_Report = "Report";
        public static readonly string PageViewCategory_Url = "Url";
        public static readonly string PageName_QuickView = "quickView";
        public static readonly string PageName_ReportsInbuilt = "reports/inbuilt";
        public static readonly string PageName_WebBrowser = "caseDetail/webBrowser";        
        public static readonly string SnippetNamePrefix_Rule = "Rule";
        public static readonly string WorkFlowHorizontalCompleteStatusName = "Complete";
        public static readonly string WorkFlowHorizontalCaseCreationStatusName = "Case Creation";
        public static readonly string WorkFlowVerticalLinkedCaseReviewStatusName = "Linked Case Review";
        public static readonly string CategoryNameParameter_CaseDetail = "CaseDetail";
        public static readonly string WorkflowAction_Assign = "A";
        public static readonly string WorkflowAction_Promote = "P";
        public static readonly string WorkflowAction_Demote = "D";
        public static readonly string PageViewName_CaseInfoView = "CaseInfoView";
        public static readonly int ApplicationModuleId_FalsePositive = 1;
        public static readonly int ApplicationModuleId_CaseManagementTool = 2;        
        public static readonly int ApplicationModuleId_LinkedCaseManagementTool = 3;
        public static readonly string ApplicationSettings_SarMessageFrom = "SARMessageFrom";
        public static readonly string ApplicationSettings_SarMessageTo = "SARMessageTo";
        public static readonly string ApplicationSettings_SarMessageSubject = "SARMessageSubject";
        public static readonly string ApplicationSettings_SarMessageBody = "SARMessageBody";
        public static readonly string ApplicationSettings_SMTPServer = "SMTPServer";
        public static readonly string ApplicationSettings_SarExportEmailSizeLimit = "SARExportEmailSizeLimit";
        public static readonly string ApplicationSettings_SupportedCaseFileExtentions = "SupportedCaseFileExtentions";
        public static readonly string ApplicationSettings_PromoteRoutesDropdownFormat = "PromoteRoutesDropdownFormat";
        public static readonly string ApplicationSettings_PromoteUsersDropdownFormat = "PromoteUsersDropdownFormat"; 
        public static readonly string ApplicationSettings_DispositionNoteHistoryItemCount = "DispositionNoteHistoryItemCount";
        public static readonly string ApplicationSettings_SupportedDispositionFileExtensions = "SupportedDispositionFileExtensions";
        public static readonly string ApplicationSettings_EnableFalsePositiveApplyAll = "EnableFalsePositiveApplyAll";
        public static readonly string ApplicationSettings_RfiRequestBodyTemplate = "RfiRequestBodyTemplate";
        public static readonly string ApplicationSettings_RfiLinkExpirationDays = "RfiLinkExpirationDays";
        public static readonly string ApplicationSettings_RfiDueDateDays = "RfiDueDateDays";
        public static readonly string ApplicationSettings_EnableRfiApprovalProcess = "EnableRFIApprovalProcess";
        public static readonly string ApplicationSettings_RfiMessageFrom = "RfiMessageFrom";
        public static readonly string ApplicationSettings_FalsePositiveClearVisible = "FalsePositiveClearVisible";
        public static readonly string ApplicationSettings_FalsePositiveRadioSelectUnknownVisible = "FalsePositiveRadioSelectUnknownVisible";
        public static readonly string ApplicationSettings_RfiLinkTemplate = "RfiLinkTemplate";
        public static readonly string ApplicationSettings_DefaultSearchOperator = "DefaultSearchOperator";
        public static readonly string ApplicationSettings_SeachCleaningRegex = "SeachCleaningRegex";
        public static readonly string ApplicationSettings_SearchPreviewNSymbols = "SearchPreviewNSymbols";
        public static readonly string ApplicationSettings_SearchPreviewNPages = "SearchPreviewNPages";
        public static readonly string ApplicationSettings_SearchPreviewHighlightClass = "SearchPreviewHighlightClass";
        public static readonly string ApplicationSettings_RfiNotificationDaysBeforeOverdue = "RfiNotificationDaysBeforeOverdue";
        public static readonly string ApplicationSettings_RfiNotificationDaysBeforeLinkExpiration = "RfiNotificationDaysBeforeLinkExpiration";
        public static readonly string ApplicationSettigns_RfiLinkClickText = "RfiLinkClickText";
        public static readonly string ApplicationSettings_StarApplicationUrl = "StarApplicationUrl";
        public static readonly string ApplicationSettings_ResetPasswordMessageFrom = "ResetPasswordMessageFrom";
        public static readonly string ApplicationSettings_ResetPasswordMessageSubject = "ResetPasswordMessageSubject";
        public static readonly string ApplicationSettings_CreatePasswordMessageSubject = "CreatePasswordMessageSubject";
        public static readonly string ApplicationSettings_ResetPasswordMessageBody = "ResetPasswordMessageBody";
        public static readonly string ApplicationSettings_CreatePasswordMessageBody = "CreatePasswordMessageBody";
        public static readonly string ApplicationSettings_ResetPasswordPage = @"/reset-password";
        public static readonly string ApplicationSettings_CreatePasswordPage = @"/create-password";
        public static readonly string ApplicationSettings_LoginPage = @"/login";
        public static readonly string ApplicationSettings_RefreshUserResetPwdTokenLifetimeInHours = "RefreshUserResetPwdTokenLifetimeInHours";
        public static readonly string ApplicationSettings_RefreshUserCreatePwdTokenLifetimeInHours = "RefreshUserCreatePwdTokenLifetimeInHours";
        public static readonly string ApplicationSettings_ADAccountRegistrationMessageSubject = "ADAccountRegistrationMessageSubject";
        public static readonly string ApplicationSettings_ADAccountRegistrationMessageBody = "ADAccountRegistrationMessageBody";
        public static readonly string ApplicationSettings_SupportedSARFileExtensions = "SupportedSARFileExtensions";
        public static readonly string ApplicationSettings_WorkflowEventsEnabled = "WorkflowEventsEnabled";
        public static readonly string ApplicationSettings_RouteEventNotificationMessageFrom = "RouteeventNotificationMessageFrom";
        public static readonly string ApplicationSettings_FooterCopyrightYear = "FooterCopyrightYear";
        public static readonly string ApplicationSettings_ApplicationVersion = "ApplicationVersion";
        public static readonly string ApplicationSettings_ColorSchema = "ColorSchema";
		public static readonly string ApplicationSettings_TranslationFileName = "TranslationFileName";

        public static readonly string AuthorizationRule_Blank = "Blank";
        public static readonly string AuthorizationRule_All = "All";
        public static readonly string AuthorizationRule_LCMTAccess = "LCMTAccess";
        public static readonly string AuthorizationRule_LCMTCreateAccess = "LCMTCreateAccess";
        public static readonly int AuthorizationRule_All_Id = -1;
        public static readonly string AuthorizationRule_CMTAccess = "CMTAccess";
        public static readonly string AuthorizationRule_BackOutCompletedCasesAccess = "BackOutCompletedCasesAccess";
        public static readonly string AuthorizationRule_CMTAssignAccess = "CMTAssignAccess";
        public static readonly string AuthorizationRule_CMTCreateAccess = "CMTCreateAccess";
        public static readonly string WorkFlowHorizontalPermissionName_SAREdit = "SAR edit";
        public static readonly string WorkFlowHorizontalPermissionName_SARRead = "SAR read";
        public static readonly string ShellMenu = "ShellMenu";
        public static readonly string AuthorizationRule_RFIManagementAccess = "RFIManagementAccess";
        public static readonly string AuthorizationRule_AdminAccess = "AdminAccess";
        public static readonly string AuthorizationRule_HomePageAccess = "HomePageAccess";

        public static readonly string CaseTypeName_RegularCase = "Regular Case";
        public static readonly string CaseTypeName_LinkedCase = "Linked Case";

        public static readonly string SnippetType_CaseSnippets = "CaseSnippets";
        public static readonly string SnippetType_HomePage = "HomePage";
        public static readonly string SnippetType_Rule = "Rule";
        public static readonly string SnippetType_Party = "Party";
        public static readonly string SnippetType_Transaction = "Transaction";
        public static readonly string SnippetType_FalsePositive = "FalsePositive";
        public static readonly string SnippetType_CaseSurvey = "CaseSurvey";

        public static readonly string FalsePositive_HitStatus_FalsePositive = "False Positive";
        public static readonly string FalsePositive_HitStatus_TruePositive= "True Positive/Match";
        public static readonly string FalsePositive_HitStatus_Unknown = "Unknown";

        public static readonly string SnippetType_FalsePositive_FircoHitDetails = "Firco Hit Details";

        public static readonly int GlobalSearch_TopResultsCount = 10000;
        public static readonly int PartyNameFilterLength = 255;

        public static readonly string Sp_SGetDataTabData = "[dbo].[SGetDataTabData]";
        public static readonly string Sp_SGetDataTabDataCount = "[dbo].[SGetDataTabDataCount]";
        public static readonly string Sp_SCaseCreationAssignItemIDs = "[dbo].[SCaseCreationAssignItemIDs]";
        public static readonly string Sp_SCaseCreationGetVerifyData = "[dbo].[SCaseCreationGetVerifyData]";
        public static readonly string Sp_SCaseCreationProcessVerifyData = "[dbo].[SCaseCreationProcessVerifyData]";
        public static readonly string Sp_SCaseCreationUnassignItemIDs = "[dbo].[SCaseCreationUnassignItemIDs]";
        public static readonly string Sp_SCaseGetAll = "[dbo].[SCaseGetAll]";
        public static readonly string Sp_SCaseGetAllCount = "[dbo].[SCaseGetAllCount]";
        public static readonly string Sp_SCaseGetByAssignedToUserID = "[dbo].[SCaseGetByAssignedToUserID]";
        public static readonly string Sp_SCaseGetByAssignedToUserIDCount = "[dbo].[SCaseGetByAssignedToUserIDCount]";
        public static readonly string Sp_SCaseGetByAssignedToUserList = "[dbo].[SCaseGetByAssignedToUserList]";
        public static readonly string Sp_SCaseGetByAssignedToUserListCount = "[dbo].[SCaseGetByAssignedToUserListCount]";
        public static readonly string Sp_SCaseGetByPartyName = "[dbo].[SCaseGetByPartyName]";        
        public static readonly string Sp_SCaseGetByWorkFlowHorizontalID = "[dbo].[SCaseGetByWorkFlowHorizontalID]";
        public static readonly string Sp_SCaseGetByWorkFlowHorizontalIDCount = "[dbo].[SCaseGetByWorkFlowHorizontalIDCount]";
        public static readonly string Sp_SCaseGetInfoByCaseID = "[dbo].[SCaseGetInfoByCaseID]";
        public static readonly string Sp_SCaseGetParties = "[dbo].[SCaseGetParties]";
        public static readonly string Sp_SCaseGetPartiesAliases = "[dbo].[SCaseGetPartiesAliases]";
        public static readonly string Sp_SCaseGetSarItems = "[dbo].[SCaseGetSarItems]";
        public static readonly string Sp_SCaseGetSarItemsCount = "[dbo].[SCaseGetSarItemsCount]";
        public static readonly string Sp_SCaseGetSarSummary = "[dbo].[SCaseGetSarSummary]";
        public static readonly string SP_SCaseFilesReassignToNewParent = "[dbo].[SCaseFilesReassignToNewParent]";
        public static readonly string Sp_SCaseItemMove = "[dbo].[SCaseItemMove]";
        public static readonly string Sp_SCaseItemSARAddItems = "[dbo].[SCaseItemSARAddItems]";
        public static readonly string Sp_SCaseItemSARGetPageViewName = "[dbo].[SCaseItemSARGetPageViewName]";
        public static readonly string Sp_SCaseRefineUnassignItemIDs = "[dbo].[SCaseRefineUnassignItemIDs]";
        public static readonly string Sp_SCaseRefreshItemCount = "[dbo].[SCaseRefreshItemCount]";
        public static readonly string Sp_SCaseViewTabsGet = "[dbo].[SCaseViewTabsGet]";
        public static readonly string Sp_SCaseViewTabsGetByItemID = "[dbo].[SCaseViewTabsGetByItemID]";
        public static readonly string Sp_SConfigGridViewColumnsByMetaObjectIDGenerate = "[dbo].[SConfigGridViewColumnsByMetaObjectIDGenerate]";
        public static readonly string Sp_SConfigMetaFunctionListGet = "[dbo].[SConfigMetaFunctionListGet]";
        public static readonly string Sp_SConfigMetaFunctionParameterListGet = "[dbo].[SConfigMetaFunctionParameterListGet]";
        public static readonly string Sp_SConfigMetaObjectSourceTableListGet = "[dbo].[SConfigMetaObjectSourceTableListGet]";
        public static readonly string Sp_SConfigMetaObjectSourceViewCreate = "[dbo].[SConfigMetaObjectSourceViewCreate]";
        public static readonly string Sp_SConfigMetaObjectSourceViewDefinitionGet = "[dbo].[SConfigMetaObjectSourceViewDefinitionGet]";
        public static readonly string Sp_SConfigMetaPropertyByMetaObjectIDGenerate = "[dbo].[SConfigMetaPropertyByMetaObjectIDGenerate]";
        public static readonly string Sp_SGridViewColumnsGet = "[dbo].[SGridViewColumnsGet]";
        public static readonly string Sp_SMenuGet = "[dbo].[SMenuGet]";
        public static readonly string Sp_SMetaObjectDataGet = "[dbo].[SMetaObjectDataGet]";
        public static readonly string Sp_SMetaObjectDataGetCount = "[dbo].[SMetaObjectDataGetCount]";
        public static readonly string Sp_SMetaObjectDraftDataGet = "[dbo].[SMetaObjectDraftDataGet]";
        public static readonly string Sp_SMetaObjectDraftDataGetCount = "[dbo].[SMetaObjectDraftDataGetCount]";
        public static readonly string Sp_SMetaObjectGetInfoByItemID = "[dbo].[SMetaObjectGetInfoByItemID]";
        public static readonly string Sp_SMetaObjectGetItemIDByNaturalKey = "[dbo].[SMetaObjectGetItemIDByNaturalKey]";
        public static readonly string Sp_SMetaObjectRelateDataGet = "[dbo].[SMetaObjectRelateDataGet]";
        public static readonly string Sp_SMetaObjectRelateDataGetCount = "[dbo].[SMetaObjectRelateDataGetCount]";
        public static readonly string Sp_SMetaObjectRelateDraftDataGet = "[dbo].[SMetaObjectRelateDraftDataGet]";
        public static readonly string Sp_SMetaObjectRelateDraftDataGetCount = "[dbo].[SMetaObjectRelateDraftDataGetCount]";
        public static readonly string Sp_SPartyGetByAlias = "[dbo].[SPartyGetByAlias]";
        public static readonly string Sp_SPartyGetByAliasCount = "[dbo].[SPartyGetByAliasCount]";
        public static readonly string Sp_SCaseGetByPartyIDPartyAliasID = "[dbo].[SCaseGetByPartyIDPartyAliasID]";
        public static readonly string Sp_SPartyGetByCaseID = "[dbo].[SPartyGetByCaseID]";
        public static readonly string Sp_SPartyGetByCaseIDCount = "[dbo].[SPartyGetByCaseIDCount]";
        public static readonly string Sp_SReportGetRulesReportData = "[dbo].[SReportGetRulesReportData]";
        public static readonly string Sp_SRuleGetByRuleID = "[dbo].[SRuleGetByRuleID]";
        public static readonly string Sp_SGetWorkFlowHorizontalFiltered = "[dbo].[SGetWorkFlowHorizontalFiltered]";
        public static readonly string Sp_SGetWorkFlowHorizontalRoles = "[dbo].[SGetWorkFlowHorizontalRoles]";
        public static readonly string Sp_SWorkFlowHorizontalUpdateRolesAndPermissions = "[dbo].[SWorkFlowHorizontalUpdateRolesAndPermissions]";
        public static readonly string Sp_SGetWorkFlowHorizontalRulesPermissions = "[dbo].[SGetWorkFlowHorizontalRulesPermissions]";
        public static readonly string Sp_SRuleGetByCaseID = "[dbo].[SRuleGetByCaseID]";
        public static readonly string Sp_SRuleGetHitsByItemID = "[dbo].[SRuleGetHitsByItemID]";
        public static readonly string Sp_SRuleGetHitsByRuleIDCaseID = "[dbo].[SRuleGetHitsByRuleIDCaseID]";
        public static readonly string Sp_SRuleGetSearchTermsByRuleInputIDRuleIDCaseID = "[dbo].[SRuleGetSearchTermsByRuleInputIDRuleIDCaseID]";
        public static readonly string Sp_SRuleGetSnippetXml = "[dbo].[SRuleGetSnippetXml]";
        public static readonly string Sp_SSARCasesGetByPartyIDAlias = "[dbo].[SSARCasesGetByPartyIDAlias]";
        public static readonly string Sp_STransactionGetByPartyNameCaseID = "[dbo].[STransactionGetByPartyNameCaseID]";
        public static readonly string Sp_STransactionGetByPartyNameCaseIDCount = "[dbo].[STransactionGetByPartyNameCaseIDCount]";
        public static readonly string Sp_SUserPreferenceSave = "[dbo].[SUserPreferenceSave]";
        public static readonly string Sp_SWorkFlowGetAssignmentUserList = "[dbo].[SWorkFlowGetAssignmentUserList]";
        public static readonly string Sp_SWorkFlowPositionGet = "[dbo].[SWorkFlowPositionGet]";
        public static readonly string Sp_SWorkflowPositionsGetPositionsGroups = "[dbo].[SWorkflowPositionsGetPositionsGroups]";
        public static readonly string Sp_SWorkFlowPositionGetUserList = "[dbo].[SWorkFlowPositionGetUserList]";
        public static readonly string Sp_SPartyMergeAlias = "[dbo].[SPartyMergeAlias]";
        public static readonly string Sp_SFalsePositiveGetSummary = "[dbo].[SFalsePositiveGetSummary]";
        public static readonly string Sp_SFalsePositiveGetByRuleInputCategoryID = "[dbo].[SFalsePositiveGetByRuleInputCategoryID]";
        public static readonly string Sp_SFalsePositiveGetByRuleInputCategoryIDCount = "[dbo].[SFalsePositiveGetByRuleInputCategoryIDCount]";
        public static readonly string Sp_SFalsePositiveUpdateHitStatus = "[dbo].[SFalsePositiveUpdateHitStatus]";
        public static readonly string Sp_SFalsePositivePromote = "[dbo].[SFalsePositivePromote]";
        public static readonly string Sp_SFalsePositiveGetActiveWorkFlow = "[dbo].[SFalsePositiveGetActiveWorkFlow]";
        public static readonly string Sp_SFalsePositivePromoteList = "[dbo].[SFalsePositivePromoteList]";
        public static readonly string Sp_SFalsePositiveReassignList = "[dbo].[SFalsePositiveReassignList]";
        public static readonly string Sp_SMetaObjectSnippetGetRulesByMetaObjectIDItemID = "[dbo].[SMetaObjectSnippetGetRulesByMetaObjectIDItemID]";

        public static readonly string F_FCheckUltimatePartyByCaseIDPartyID = "[dbo].[FCheckUltimatePartyByCaseIDPartyID]";
        public static readonly string Sp_SCaseRFIGetByCaseID = "[rfi].[SCaseRFIGetByCaseID]";
        public static readonly string Sp_SCaseRFIGetHistoryByCaseRfiId = "[rfi].[SCaseRFIGetHistoryByCaseRfiID]";
        public static readonly string Sp_FalsePositiveGetItemCounts = "[dbo].[SFalsePositiveGetItemCounts]";
        public static readonly string Sp_SFalsePositivesWorkflowHistoryGet = "[dbo].[SFalsePositiveWorkFlowHistoryGet]";
        public static readonly string Sp_SSearchGetResults = "[dbo].[SSearchGetResults]";
        public static readonly string Sp_SFalsePositiveGetByWorkFlowPositionID = "[dbo].[SFalsePositiveGetByWorkFlowPositionID]";
        public static readonly string Sp_SFalsePositiveGetByWorkFlowPositionIDCount = "[dbo].[SFalsePositiveGetByWorkFlowPositionIDCount]";
        public static readonly string Sp_SReportGet = "[dbo].[SReportGet]";
        public static readonly string Sp_SCaseGetRootMetaObjectPageViewName = "[dbo].[SCaseGetRootMetaObjectPageViewName]";
        public static readonly string Sp_SCaseCreationCheckValidCaseAssignment = "[dbo].[SCaseCreationCheckValidCaseAssignment]";
        public static readonly string Sp_SCaseRFIGetOverdueNotification = "[rfi].[SCaseRFIGetOverdueNotification]";
        public static readonly string Sp_SCaseRFIGetLinkExpirationNotification = "[rfi].[SCaseRFIGetLinkExpirationNotification]";
        public static readonly string Sp_SCaseGetLinkedCasesByCaseID = "[dbo].[SCaseGetLinkedCasesByCaseID]";
        public static readonly string Sp_SCaseGetCasesForLinking = "[dbo].[SCaseGetCasesForLinking]";
        public static readonly string Sp_SCaseGetCasesForLinkingCount = "[dbo].[SCaseGetCasesForLinkingCount]";
        public static readonly string Sp_SWorkFlowPositionGetByCheckListID = "[dbo].[SWorkFlowPositionGetByCheckListID]";
        public static readonly string Sp_SApplicationLogGet = "[dbo].[SApplicationLogGet]";
        public static readonly string Sp_SApplicationLogGetByID = "[dbo].[SApplicationLogGetByID]";
        public static readonly string Sp_SConfigMetaObjectGetActionAvailability = "[dbo].[SConfigMetaObjectGetActionAvailability]";
        public static readonly string Sp_SConfigMetaPropertyGetFieldsByMetaObjectID = "[dbo].[SConfigMetaPropertyGetFieldsByMetaObjectID]";
        public static readonly string Sp_SConfigGetFieldsByTableName = "[dbo].[SConfigGetFieldsByTableName]";
        public static readonly string Sp_SConfigGetXREFTable = "[dbo].[SConfigGetXREFTable]";
        public static readonly string Sp_SConfigGetXREFView = "[dbo].[SConfigGetXREFView]";
        public static readonly string Sp_SCaseDispositionGetUsingByPartyName = "[dbo].[SCaseDispositionGetUsingByPartyName]";
        public static readonly string Sp_SConfigMetaObjectValidate = "[dbo].[SConfigMetaObjectValidate]";
        public static readonly string Sp_SConfigSnippetStoredProcedureListGet = "[dbo].[SConfigSnippetStoredProcedureListGet]";
        public static readonly string Sp_SCaseAssignPromote = "[dbo].[SCaseAssignPromote]";
        public static readonly string Sp_SSnippetGetPreviewDataList = "[dbo].[SSnippetGetPreviewDataList]";
        public static readonly string Sp_SConfigMetaObjectPopulateItemsGetCount = "[dbo].[SConfigMetaObjectPopulateItemsGetCount]";
        public static readonly string Sp_SConfigMetaObjectPopulateItemsToBeProcessedGetCount = "[dbo].[SConfigMetaObjectPopulateItemsToBeProcessedGetCount]";
        public static readonly string Sp_SConfigMetaObjectPopulateItems = "[dbo].[SConfigMetaObjectPopulateItems]";
        public static readonly string Sp_SDeleteItemProcessVerifyData = "SDeleteItemProcessVerifyData";
        public static readonly string Sp_SItemsDelete = "SItemsDelete";
        public static readonly string SsrsReport_RulesReport = "RulesReport";

        public static readonly string AccessTokenPurpose_CreatePassword = "CreatePassword";
        public static readonly string AccessTokenPurpose_ResetPassword = "ResetPassword";

        public static readonly string PageViewName_PrivacyPolicyView = "PrivacyPolicyView";        
        public static readonly string PageViewName_TermsOfUseView = "TermsOfUseView";
        public static readonly string PageViewName_UserGuideView = "UserGuideView";
    }

    public class WorkFlowRouteConstants
    {
        public static readonly string ReadyForAssignment = "Ready for assignment";

        
    }

    public struct RfiStatusNameConst
    {
        public const string PendingApproval = "Pending Approval";
        public const string Rework = "Re-work";
        public const string Submitted = "Submitted";
        public const string Responded = "Responded";
        public const string Resubmitted = "Resubmitted";
        public const string Closed = "Closed";
        public const string Withdrawn = "Withdrawn";
        public const string Overdue = "Overdue";
        public const string Expired = "Expired";
        public const string Approved = "Approved";
    }

    public struct RfiNotificationTypeNameConst
    {
        public const string StatusChange = "Status Change";
        public const string DueDateWarning = "Due Date Warning";
        public const string LinkExpirationWarning = "Link Expiration Warning"; 
    }
    
    public struct RfiNotificationRecipientTypeNameConst
    {
        public const string RfiReceiver = "RFI Receiver";
        public const string RfiSender = "RFI Sender";
        public const string RfiManagerRole = "RFI Manager Role";
    }

    public struct RfiNotificationAuditStatusConst
    {
        public const string Created = "Created";
        public const string Sent = "Sent";
        public const string Error = "Error";
    }

    public struct SearchProviderCategoryConst
    {
        public const string CaseDispositions = "Case Dispositions";
        public const string CaseDispositionNote = "Case Disposition Notes";
        public const string Party = "Parties";
        public const string Cases = "Cases";
        public const string CaseFiles = "Case Files";
        public const string Rules = "Rules";
        public const string KnowledgeBase = "Knowledge Base";
        public const string CheckList = "Check-list";
        public const string RuleInputDoc = "Rule Input Doc";
    }

    public struct TextExtractorFileTypeConst
    {
        public const string Doc = "doc";
        public const string Docx = "docx";
        public const string Pdf = "pdf";
    }

    public struct SnippetTypeNameConst
    {
        public const string Transaction = "Transaction";
        public const string Account = "Account";
        public const string Party = "Party";
        public const string Rule = "Rule";
        public const string CaseFile = "CaseFile";
        public const string CaseSnippets = "CaseSnippets";
        public const string CaseDispositions = "CaseDispositions";
        public const string Case = "Case";
        public const string FalsePositive = "FalsePositive";
        public const string HomePage = "HomePage";
        public const string CaseSurvey = "CaseSurvey";
    }

    public struct MetaPropertyTypeNameConst
    {
        public const string Field = "Field";
        public const string Function = "Function";
        public const string Collection = "Collection";
    }

    public struct PdfFileConverterFileTypeConst
    {
        public const string Csv = "csv";
        public const string Doc = "doc";
        public const string Docx = "docx";
        public const string Txt = "txt";
        public const string Html = "html";
        public const string Msg = "msg";
        public const string Pdf = "pdf";
        public const string Ppt = "ppt";
        public const string Xls = "xls";
        public const string Xlsx = "xlsx";
        public const string Xlsm = "xlsm";
        public const string Xml = "xml";
        public const string Xps = "xps";
        public const string Tiff = "tiff";
        public const string Tif = "tif";
    }

    public struct RouteEventActionCommandConst
    {
        public const string EnqueueSurveyAssignedToRMEmailEventAction = "EnqueueSurveyAssignedToRMEmailEventAction";
        public const string EnqueueSurveyDemotedToRMEmailEventAction = "EnqueueSurveyDemotedToRMEmailEventAction";
    }

    public struct WorkFlowRouteEventAuditStatusConst
    {
        public const string Sent = "Sent";
        public const string Error = "Error";
    }
}
