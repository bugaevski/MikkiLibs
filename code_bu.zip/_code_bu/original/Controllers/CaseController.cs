﻿using Star.ActionResults;
using Star.Commands;
using Star.Queries;
using Star.Queries.Results;
using Star.QueryHandlers.Interfaces;
using System;
using System.Collections.Generic;
using System.Web.Http;
using Star.Controllers.Base;
using Swashbuckle.Swagger.Annotations;
using System.Security.Claims;
using Star.Common.AspNetIdentity;
using Star.CommandHandlers.Base.Interfaces;
using Star.Queries.Queries;
using Star.Common;
using NLog;
using System.Web;

namespace Star.Controllers
{
    [RoutePrefix("api/Case")]
    public class CaseController : BaseGridController
    {
        private readonly IQueryHandler<GetAllCasesQry, string> _getAllCasesQ;
        private readonly ICommandHandler<UpdateCaseFollowUpFlagCmd> _updateFollowUpFlagCmd;
        private readonly ICommandHandler<RemoveCasesFromTagCmd> _removeCasesFromTagCmd;
        private readonly ICommandHandler<AddCasesToTagCmd> _addCasesToTagCmd;
        private readonly IQueryHandler<GetCaseViewHistoryLightQry, IEnumerable<CaseViewHistoryLightResult>> _caseViewHistoryLightQ;
        private readonly IQueryHandler<GetAllCasesCountQry, CountResult> _allCasesCountQ;
        private readonly IQueryHandler<GetAssignedCasesQry, string> _assignedCasesQ;
        private readonly IQueryHandler<GetAllCaseStatusesQry, IEnumerable<AllCaseStatusesResult>> _allCaseStatusesQ;
        private readonly ICommandHandler<RemoveCaseTagsCmd> _removeCaseTagsCmd;
        private readonly IQueryHandler<GetIsCaseCreationPositionQry, bool> _isCaseCreationStatusQ;
        private readonly IQueryHandler<IsCaseAllowToManageQry, bool> _isCaseExistsQ;
        private readonly IQueryHandler<GetCaseType, string> _getCaseTypeQry;
        private readonly IQueryHandler<IsCaseLockedQry, bool> _isCaseLockedQ;
        private readonly IQueryHandler<IsCaseLinkingAllowedQry, bool> _isCaseLinkingAllowedQ;
        private readonly IQueryHandler<GetAllCaseCategoriesQry, IEnumerable<CaseCategoryResult>> _caseCategoriesQ;
        private readonly IQueryHandler<GetCaseCategoriesQry, IEnumerable<CaseCategorySelectionResult>> _caseCategoriesSelectionQ;
        private readonly ICommandHandler<UpdateCaseCategoryCmd> _updateCaseCategoryCmd;
        private readonly ICommandHandler<UpdateCaseNameCmd> _updateCaseNameCmd;
        private readonly IQueryHandler<GetCreationPositionsQry, int[]> _creationPositionsQ;
        
        public CaseController(
            IQueryHandler<GetAllCasesQry, string> getAllCasesQ,
            ICommandHandler<UpdateCaseFollowUpFlagCmd> updateFollowUpFlagCmd,
            ICommandHandler<RemoveCasesFromTagCmd> removeCasesFromTagCmd,
            ICommandHandler<AddCasesToTagCmd> addCasesToTagCmd,
            IQueryHandler<GetGridSettingsQry, IEnumerable<GridViewColumnResult>> gridViewColumnsQ,
            IQueryHandler<GetCaseViewHistoryLightQry, IEnumerable<CaseViewHistoryLightResult>> caseViewHistoryLightQ,
            IQueryHandler<GetAllCasesCountQry, CountResult> allCasesCountQ,
            IQueryHandler<GetAssignedCasesQry, string> assignedCasesQ,
            IQueryHandler<GetAllCaseStatusesQry, IEnumerable<AllCaseStatusesResult>> allCaseStatusesQ,
            ICommandHandler<RemoveCaseTagsCmd> removeCaseTagsCmd,
            IQueryHandler<GetIsCaseCreationPositionQry, bool> isCaseCreationStatusQ,
            IQueryHandler<IsCaseAllowToManageQry, bool> isCaseExistsQ,
            IQueryHandler<GetCaseType, string> getCaseTypeQ,
            IQueryHandler<IsCaseLockedQry, bool> isCaseLockedQ,
            IQueryHandler<IsCaseLinkingAllowedQry, bool> isCaseLinkingAllowedQ,
            IQueryHandler<GetAllCaseCategoriesQry, IEnumerable<CaseCategoryResult>> caseCategoriesQ,
            IQueryHandler<GetCaseCategoriesQry, IEnumerable<CaseCategorySelectionResult>> caseCategoriesSelectionQ,
            ICommandHandler<UpdateCaseCategoryCmd> updateCaseCategoryCmd,
            ICommandHandler<UpdateCaseNameCmd> updateCaseNameCmd,
            IQueryHandler<GetCreationPositionsQry, int[]> creationPositionsQ)
            : base(gridViewColumnsQ)
        {
            _getAllCasesQ = getAllCasesQ;
            _updateFollowUpFlagCmd = updateFollowUpFlagCmd;
            _removeCasesFromTagCmd = removeCasesFromTagCmd;
            _addCasesToTagCmd = addCasesToTagCmd;
            _caseViewHistoryLightQ = caseViewHistoryLightQ;
            _allCasesCountQ = allCasesCountQ;
            _assignedCasesQ = assignedCasesQ;
            _allCaseStatusesQ = allCaseStatusesQ;
            _removeCaseTagsCmd = removeCaseTagsCmd;
            _isCaseCreationStatusQ = isCaseCreationStatusQ;
            _isCaseExistsQ = isCaseExistsQ;
            _getCaseTypeQry = getCaseTypeQ;
            _isCaseLockedQ = isCaseLockedQ;
            _isCaseLinkingAllowedQ = isCaseLinkingAllowedQ;
            _caseCategoriesQ = caseCategoriesQ;
            _caseCategoriesSelectionQ = caseCategoriesSelectionQ;
            _updateCaseCategoryCmd = updateCaseCategoryCmd;
            _updateCaseNameCmd = updateCaseNameCmd;
            _creationPositionsQ = creationPositionsQ;
        }

        [Authorize(Roles = "CMTAccess")]
        [Route("dataList")]
        public IHttpActionResult GetDataList(int? startRow = null, int? endRow = null, [FromUri] int[] tagIds = null)
        {
            var userId = (this.RequestContext.Principal.Identity as ClaimsIdentity).GetUserId();
            
            if (tagIds != null && tagIds.Length == 0)
            {
                tagIds = null;
            }

            var result = _getAllCasesQ.Handle(new GetAllCasesQry() { StartRow = startRow, EndRow = endRow, UserId = userId, TagIds = tagIds, CaseTypeName = Constants.CaseTypeName_RegularCase });

            if (String.IsNullOrEmpty(result))
            {
                return NotFound();
            }
            
            return new StringAsJsonResult(result, Request);
        }

        [Authorize(Roles = "CMTAccess")]
        [Route("dataListCount")]
        [HttpGet]
        public IHttpActionResult GetDataListCount([FromUri] int[] tagIds = null)
        {
            var userId = (this.RequestContext.Principal.Identity as ClaimsIdentity).GetUserId();

            if (tagIds != null && tagIds.Length == 0)
            {
                tagIds = null;
            }

            var result = _allCasesCountQ.Handle(new GetAllCasesCountQry() { UserId = userId, TagIds = tagIds, CaseTypeName = Constants.CaseTypeName_RegularCase });

            return Ok(result);
        }

        [Authorize(Roles = "CMTAccess")]
        [Route("updateFollowUpFlag")]
        [HttpPut]
        public IHttpActionResult UpdateFollowUpFlag(UpdateCaseFollowUpFlagCmd command)
        {
            command.ModifiedByUserId = (this.RequestContext.Principal.Identity as ClaimsIdentity).GetUserId();
            _updateFollowUpFlagCmd.Handle(command);
            return Ok();
        }

        [Authorize(Roles = "CMTAccess")]
        [Route("removeCasesFromTag")]
        [HttpDelete]
        public IHttpActionResult RemoveCasesFromTag(RemoveCasesFromTagCmd command)
        {
            _removeCasesFromTagCmd.Handle(command);
            return Ok();
        }

        [Authorize(Roles = "CaseTagAdminAccess")]
        [Route("addCasesToTag")]
        [HttpPost]
        public IHttpActionResult AddCasesToTag(AddCasesToTagCmd command)
        {
            _addCasesToTagCmd.Handle(command);
            return Ok();
        }

        [Authorize(Roles = "CMTAccess")]
        [SwaggerResponse(200, "", typeof(IEnumerable<CaseViewHistoryLightResult>))]
        [Route("getCaseViewHistoryLight")]
        [HttpGet]
        public IHttpActionResult GetCaseViewHistoryLight(int caseId)
        {
            var result = _caseViewHistoryLightQ.Handle(new GetCaseViewHistoryLightQry { CaseId = caseId });

            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
                
        [Authorize(Roles = "CMTAccess")]
        [SwaggerResponse(200, "", typeof(IEnumerable<CaseViewHistoryLightResult>))]
        [Route("caseViewHistoryDataList")]
        [HttpGet]
        public IHttpActionResult GetCaseViewHistoryDataList(int caseId)
        {
            var result = _caseViewHistoryLightQ.Handle(new GetCaseViewHistoryLightQry { CaseId = caseId });

            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        [Authorize(Roles = "CMTAccess")]
        [Route("getAssignedCases")]
        [HttpGet]
        public IHttpActionResult GetAssignedCases([FromUri] Guid[] userIds, int? startRow = null, int? endRow = null)
        {
            var result = _assignedCasesQ.Handle(new GetAssignedCasesQry
            {
                UserIds = userIds,
                StartRow = startRow,
                EndRow = endRow,
                CaseTypeName = Constants.CaseTypeName_RegularCase
            });

            if (String.IsNullOrEmpty(result))
            {
                return NotFound();
            }

            return new StringAsJsonResult(result, Request);
        }

        [Authorize(Roles = "CMTAccess")]
        [SwaggerResponse(200, "", typeof(IEnumerable<AllCaseStatusesResult>))]
        [Route("getAllCaseStatuses")]
        [HttpGet]
        public IHttpActionResult GetAllCaseStatuses(int applicationModuleId)
        {
            var result = _allCaseStatusesQ.Handle(new GetAllCaseStatusesQry() { ApplicationModuleId = applicationModuleId });

            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }

        [Authorize(Roles = "CaseTagAdminAccess")]
        [Route("removeCaseTags")]
        [HttpDelete]
        public IHttpActionResult RemoveCaseTags(RemoveCaseTagsCmd command)
        {
            _removeCaseTagsCmd.Handle(command);
            return Ok();
        }

        [Authorize()]
        [SwaggerResponse(200, "", typeof(bool))]
        [Route("isCaseCreationPosition")]
        public IHttpActionResult GetIsCaseCreationPosition(int caseId)
        {
            var result = _isCaseCreationStatusQ.Handle(new GetIsCaseCreationPositionQry { CaseId = caseId });

            return Ok(result);
        }

        [SwaggerResponse(200, "", typeof(bool))]
        [Authorize()]
        [Route("isCaseManagementAllowed")]
        [HttpGet]
        public IHttpActionResult IsCaseManagementAllowed(int caseId)
        {
            var query = new IsCaseAllowToManageQry() { CaseId = caseId };
            query.UserId = ((ClaimsIdentity)System.Web.HttpContext.Current.User.Identity).GetUserId();

            var result = _isCaseExistsQ.Handle(query);
            return Ok(result);
        }

        [Authorize(Roles = "CMTAccess")]
        [Route("getCaseType")]
        [HttpGet]
        public IHttpActionResult GetCaseType(int caseId)
        {
            var result = _getCaseTypeQry.Handle(new GetCaseType { CaseId = caseId });

            return Ok(result);
        }

        [Authorize(Roles = "CMTAccess")]
        [Route("isCaseLocked")]
        [HttpGet]
        public IHttpActionResult IsCaseLocked(int caseId)
        {
            var result = _isCaseLockedQ.Handle(new IsCaseLockedQry {CaseId = caseId});
            return Ok(result);
        }
        
        [Authorize()]
        [SwaggerResponse(200, "", typeof(bool))]
        [Route("isCaseLinkingAllowed")]
        [HttpPost]
        public IHttpActionResult GetIsCaseLinkingAllowance(IsCaseLinkingAllowedQry qry)
        {
            qry.UserId = ((ClaimsIdentity)System.Web.HttpContext.Current.User.Identity).GetUserId();
            var result = _isCaseLinkingAllowedQ.Handle(qry);

            return Ok(result);
        }

        [Authorize(Roles = "CMTAccess")]
        [SwaggerResponse(200, "", typeof(IEnumerable<CaseCategoryResult>))]
        [Route("caseCategories")]
        [HttpGet]
        public IHttpActionResult GetCaseCategories()
        {
            var result = _caseCategoriesQ.Handle(new GetAllCaseCategoriesQry());

            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }

        [Authorize(Roles = "CMTAccess, CMTCreateAccess, LCMTAccess, LCMTCreateAccess")]
        [SwaggerResponse(200, "", typeof(IEnumerable<CaseCategorySelectionResult>))]
        [Route("caseCategoriesSelection")]
        [HttpGet]
        public IHttpActionResult GetCaseCategoriesSelection(int caseId)
        {
            var result = _caseCategoriesSelectionQ.Handle(new GetCaseCategoriesQry { CaseId = caseId });

            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }

        [Authorize(Roles = "CMTAccess, CMTCreateAccess, LCMTAccess, LCMTCreateAccess")]
        [Route("updateCaseCategory")]
        [HttpPut]
        public IHttpActionResult UpdateCaseCategory(UpdateCaseCategoryCmd command)
        {
            command.ModifiedByUserId = (this.RequestContext.Principal.Identity as ClaimsIdentity).GetUserId();
            _updateCaseCategoryCmd.Handle(command);

            return Ok();
        }

        [Authorize(Roles = "CMTAccess, CMTCreateAccess, LCMTAccess, LCMTCreateAccess")]
        [Route("updateCaseName")]
        [HttpPut]
        public IHttpActionResult UpdateCaseName(UpdateCaseNameCmd command)
        {
            command.ModifiedByUserId = (this.RequestContext.Principal.Identity as ClaimsIdentity).GetUserId();
            _updateCaseNameCmd.Handle(command);

            return Ok();
        }

        [Authorize()]
        [SwaggerResponse(200, "", typeof(bool))]
        [Route("creationPositions")]
        [HttpGet]
        public IHttpActionResult GetCreationPositions()
        {
            var result = _creationPositionsQ.Handle(new GetCreationPositionsQry());

            return Ok(result);
        }

    }
}