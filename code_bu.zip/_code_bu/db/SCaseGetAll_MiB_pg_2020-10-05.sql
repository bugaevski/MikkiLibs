--[MiB]: 


--CREATE 
ALTER
--DROP
PROCEDURE [dbo].[SCaseGetAll_MiB_pg] (
       @PageNumber int = NULL, 
       @PageSize int = NULL, 

       @TagIDs XML = NULL,
       @UserID UNIQUEIDENTIFIER, -- to check if cases in Case Creation position have to be available for User
       @CaseTypeID INT = 1 -- RegularCase
)
AS
BEGIN

       CREATE TABLE #TCaseWithTags(CaseID INT NOT NULL, TagName NVARCHAR(max) NOT NULL);
       
       DECLARE @PageViewName NVARCHAR(100) 
       DECLARE @PageViewID INT
       
       DECLARE @ClusteredKeyColumn NVARCHAR(128) = 'CaseID'
       DECLARE @ColumnList NVARCHAR(max)
       DECLARE @SQL NVARCHAR(max)
       DECLARE @SQLTagFROM NVARCHAR(max) = ''
       DECLARE @SQLPaginationStart NVARCHAR(max)
       DECLARE @SQLPaginationEnd NVARCHAR(max)
       DECLARE @ApplicationModuleID INT

       SET @ApplicationModuleID = COALESCE(
              (SELECT MAX(ApplicationModuleID)
                     FROM dbo.TCaseType 
                     WHERE CaseTypeID = @CaseTypeID),
              2)
       
       
       IF @CaseTypeID = 1
              SET @PageViewName = 'allCasesView'
       ELSE 
              SET @PageViewName = 'allLinkedCasesView'
       
       SELECT @PageViewID = PageViewID
              FROM dbo.TPageView
              WHERE PageViewName = @PageViewName;

       
       DECLARE @SQLExclusionConditionOnCreatePosition NVARCHAR(max) = ''
       DECLARE @CreatePositionList NVARCHAR(max)
       
       --[curr...]
       IF @UserID IS NOT NULL 
              AND NOT EXISTS(SELECT 1 
                                         FROM aspnet_UserXRole ur WITH (NOLOCK)
                                         JOIN TRoleXAuthorizationRule rar WITH (NOLOCK) ON rar.RoleID = ur.RoleId
                                         JOIN TAuthorizationRule ar WITH (NOLOCK) ON ar.AuthorizationRuleID = rar.AuthorizationRuleID
                                         WHERE ar.Name = CASE WHEN @CaseTypeID = 2 THEN 'LCMTCreateAccess' ELSE 'CMTCreateAccess' END
                                                AND ur.UserId = @UserID
              )
       BEGIN
              -- show cases in Case Creation position only if User has CMTCreateAccess Authorization Rule
              SELECT @CreatePositionList = COALESCE(@CreatePositionList, '') + ', '+ CAST(wp.WorkFlowPositionID as NVARCHAR(10))
                     FROM dbo.TWorkFlowPosition wp WITH (NOLOCK)
                     JOIN dbo.TWorkFlowHorizontal wh WITH (NOLOCK) 
                           ON wh.WorkFlowHorizontalID = wp.WorkFlowHorizontalID 
                           AND wh.ApplicationModuleID = @ApplicationModuleID
                           AND wh.IsCreationPosition = 1

              SET @CreatePositionList = STUFF(@CreatePositionList, 1, 2, '')
              IF @CreatePositionList <> ''
              BEGIN
                     SET @SQLExclusionConditionOnCreatePosition = ' AND cd.WorkflowPositionID NOT IN (' + @CreatePositionList + ')'
              END
       END

       -- Build column list of result set
       SELECT @ColumnList = [dbo].FGridViewColumnsGetFieldListString (@PageViewID, 'cd', 'VCaseDisplay')

       -- Analyze tag filters
       IF @TagIDs IS NOT NULL
       BEGIN
       
              ;WITH Tags AS (
                     SELECT CaseTagID
                     FROM (
                           SELECT DISTINCT CaseTagID.value('.', 'INT') as CaseTagID
                           FROM @TagIDs.nodes('/Tags/TagID') as tag(CaseTagID)
                     ) tag
                     WHERE CaseTagID IS NOT NULL
              ),
       
              CaseXCaseTags AS (
                     SELECT CCT.CaseID, CT.[TagName]
                     FROM TCaseXCaseTag CCT 
                     JOIN Tags TAG ON TAG.CaseTagID = CCT.CaseTagID
                     JOIN TCaseTag CT ON CT.CaseTagID = CCT.CaseTagID
              ),
              CasesByTags AS (
                     SELECT DISTINCT CaseID
                           FROM CaseXCaseTags
              )  
              
              INSERT INTO #TCaseWithTags(CaseID, TagName)
              SELECT CaseID, 
                           STUFF((SELECT ',' + CaseXCaseTags.TagName FROM CaseXCaseTags WHERE CaseXCaseTags.CaseID = CasesByTags.CaseID FOR XML PATH('')), 1, 1, '') as TagName
              FROM CasesByTags;
              

              SET @SQLTagFROM = 'INNER JOIN #TCaseWithTags CaseWithTags ON CaseWithTags.CaseID = cd.CaseID'

       END

       
       SET @ColumnList = [dbo].FCaseAdditionalColumnsAdd (@ColumnList, 0 /*@AddDaysColumns*/, CASE WHEN @TagIDs IS NOT NULL THEN 1 ELSE 0 END /*@AddTagName*/)

       ----declare @pagingFilter varchar(max)
       ----select @pagingFilter = 
       ----       case 
       ----              when @StartRow is not null then 
       ----                     '; with cte as ( select CaseID from TCase' 
       ----                     + ')'
       ----                     ----'; with cte as ( select CaseID from TCase where CaseID >= ' 
       ----                     ----+ CAST((@StartRow + 100000) as varchar(10)) 
       ----                     ----+ ' and CaseID <= ' 
       ----                     ----+ CAST((@EndRow + 100000) as varchar(10)) 
       ----                     ----+ ')'
       ----              else       
       ----                     '; with cte as ( select 1 as CaseID ) '
       ----       end

       --[MiB] @PageNumber @PageSize
       DECLARE @mibPagination varchar(max), @mibODRERBY varchar(max), @skip int, @show int
       SET @skip=(@PageNumber-1)*@PageSize
       SET @mibODRERBY=' ORDER BY cd.[caseId]'
       SET @mibPagination=
       ' OFFSET '
       + CAST(@skip as varchar(6))
       + ' ROWS FETCH NEXT '
       + CAST(@PageSize as varchar(6))
       + ' ROWS ONLY'

       SET @SQL = 
              'SELECT ' 
              + @ColumnList 
              + ' FROM VCaseDisplay cd ' 
              ----+ ' INNER JOIN cte ON cd.CaseID = cte.CaseID OR cte.CAseID = 1 '
              + @SQLTagFROM 
              + @mibODRERBY
              + @mibPagination
--DEBUG
--PRINT @SQL

       EXEC sp_executesql @SQL, N'@CaseTypeID INT', @CaseTypeID = @CaseTypeID;

END
